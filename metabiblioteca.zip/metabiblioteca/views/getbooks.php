<?php
//Importar Modelo
include_once 'models/book.php';

//Instancia de Conexion
$request_obj = new Connection('books');
//Consulta con cuenta de elementos
$request_count = (int)$request_obj->con_select_single("count(title)","book");
//Consulta de elementos
$request = $request_obj->con_select_single_array("*","book");
//Arreglo vacio para guardar resultados
$array_results =[];
//Ciclo para obtener cada elemento de la consulta
for ($i=0; $i < $request_count; $i++) {
    //Fetch a constulta
    $obj_it = mysqli_fetch_array($request);
    //Variables obtenidas
    $publish_date = $obj_it[0];
    $title = $obj_it[1];
    $author_id = $obj_it[2];
    // Depuracion de salida
    //echo "\n".$publish_date;
    //echo "\n".$title;
    
    //Validacion de existencia de autor
    $id_count = (int)$request_obj->con_select_array("count(name)","author","id = '".$author_id."'");
    //Si no existe en base de datos el id se asigna undefined al autor
    $author = "Undefined";
    //Consulta de nombre del autor
    if($id_count > 0){
        $author = $request_obj->con_select_array("name","author","id = '".$author_id."'");
        //depuracion por autor
        //echo " Author ".$author[0];
    }
    //Creacion de objeto por libro
    $obj_book = array("title" => $title,"publish_date"=> $publish_date,"author" => $author[0]);
    //Depuracion de objeto
    //echo "\n".$obj_json;
    array_push($array_results,$obj_book);
    //echo "\n__________________________\n";
}

//Creacion de objeto final
$objeto_final = array("results"=>$array_results);
//Encoding de objeto json
$obj_json = json_encode($objeto_final);
//Mostrar salida de objeto json
echo $obj_json;