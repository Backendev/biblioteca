<?php 
//importar modelo de autor
include_once 'models/author.php';

//Asignacion de valor name por Envio con metodo Post
$author_name = $_POST['name'];
//Validacion de tipo de dato
if(is_string($author_name)){
    $author = new Author($author_name);
    $author->sendAuthor();
    //Mensaje de Exito
    echo "\n\nSe agrega ".$author_name;
}
else{
    //Mensaje de Error
    echo "\n\nNo se pudo agregar ".$author_name."\nVerificar!!";
}


?>
