function send(option) {
  //Envio de peticiones
  //Envio hacia setauthors - POST
  if (option === "author") {
    try {
      //Toma de valor name
      var name_field = $("#authorname").val();
      //Verificacion de tipo de valor
      name_field.toString();
      //Peticion Ajax
      $.post("/metabiblioteca/setauthors", { name: name_field }, function (
        data
      ) {
        //Impresion de salida de peticion en Elemento Div #response
        $("#response").html(data);
      });
    } catch {
      //Manejo de errores
      alert("Error data Type :(\n Please Confirm!!");
    }
  }
  //Envio hacia setbook -POST
  if (option === "book") {
    //alert("book");
    //Toma de variables desde inputs
    var publish_date_field = $("#publish_date").val();
    var title_field = $("#title").val();
    var author_id_field = $("#author_id").val();
    //Verificacion tipo de dato titulo
    title = title_field.toString();
    //Depuracion tipo de dato titulo
    //console.log(typeof title);
    author_id = parseInt(author_id_field);
    //Depuracion tipo de dato id autor
    //console.log(typeof author_id + " --" + author_id);
    //Verificacion de tipó de dato title
    if (typeof title === "string") {
      //Verificacion de tipó de dato autor id
      if (isNaN(author_id) === false) {
        try {
          //Toma de dato publish date y conversion a tipo de fecha
          datec = new Date(publish_date_field);
          //Separacion de variabvles para re ordenamiento en caso de ser necesario
          year = datec.getFullYear();
          month = datec.getMonth();
          month = month + 1;

          day = datec.getDate();
          //Verificacion de datos para fecha
          if (
            isNaN(year) === false &&
            isNaN(month) === false &&
            isNaN(day) === false
          ) {
            //depuracion de fecha
            //console.log(year + "-" + month + "-" + day);
            //Conversion a formato deseado
            dated = year + "-" + month + "-" + day;
            //depuracion conversion
            //console.log(typeof datec);
            //envio peticion POST
            $.post(
              "/metabiblioteca/setbooks",
              { publish_date: dated, title: title, author_id: author_id },
              function (data) {
                //impresion de respuets aen elemento div #response
                $("#response").html(data);
              }
            );
            //Manejo de errores
          } else {
            alert("Date error");
          }
          //if(typeof author_id_field === )
        } catch (error) {
          alert("error");
        }
      } else {
        alert("Number incorrect");
      }
    } else {
      alert("Data Error");
    }
  }
}
//Funcion para verificacion de fechas
function verificar_fecha() {
  //toma de valores
  var publish_date_field = $("#publish_date").val();
  //creacion de instancia de objeto tipo date
  datec = new Date(publish_date_field);
  //separacion de valores
  year = datec.getFullYear();
  month = datec.getMonth();
  month = month + 1;
  day = datec.getDate();
  //creacion de Leyenda con formato parcial de la fecha ingresada
  var leyenda = "Year ->" + year + "| Month->" + month + "| Day->" + day;
  //impresion de leyenda en objeto div #response-date
  $("#response-date").html(leyenda);
  //depuracion de fecha
  //console.log(year + "-" + month + "-" + day);
}
