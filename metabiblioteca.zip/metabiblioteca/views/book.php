<div id="books">
  Books
  <div id="content">
    <div class="form-group">
      <label>Publish Date</label>
      <input
        type="text"
        id="publish_date"
        class="form-control"
        onkeyup="verificar_fecha()"
      />
      <label id="response-date">Null</label>
    </div>
    <div class="form-group">
      <label>Title</label>
      <input type="text" id="title" class="form-control" />
    </div>
    <div class="form-group">
      <label>Author Id</label>
      <input type="text" id="author_id" class="form-control" />
    </div>
    <button class="btn btn-info" onclick="send('book')">Send</button>
  </div>
  <div id="response"></div>
</div>
