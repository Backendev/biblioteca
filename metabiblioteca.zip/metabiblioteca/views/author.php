<div id="author">
    <div class="form-group">
        <label>Name</label>
        <input type="text" class="form-control" id="authorname">
        <small class="form-text">Author's Name</small>
        <button onclick=send('author')>Send</button>
    </div>
    <div id="response"></div>

</div>