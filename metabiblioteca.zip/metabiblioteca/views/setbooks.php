<?php
//Importar modelo book
include_once 'models/book.php';

//Casos para validacion de datos por medio de Expresiones regulares

//Caso paa formato fecha yyyy-mm-dd
$caso = "/^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}/";
//caso para validacion de existencia de cadenas de texto
$caso3 = "/[a-zA-Z]/";
//Caso para validacion de dato numeico con uno o dos caracteres de longitud n o nn
$caso2 = "/^[0-9]{1,2}/";

//Toma de variables enviadas por metodo POST
$date = $_POST['publish_date'];
$author_id = $_POST['author_id'];
$title = $_POST['title'];
//Validacion de fecha
$validation_date = preg_match($caso,$date);
//Validacionn de existencia de cadenas de texto en fecha
$validation_date2 = preg_match($caso3,$date);
//Condicional para evaluar -> resultado esperado validation_date = 1 [Formato de numeros y guines medios correcto]
//y validation_date2 = 0 -> Validacion de que no existan cadenas de texto en el dato
if($validation_date == 1 and $validation_date2 == 0){
    //Depuracion de validacion paa fecha
    //echo "correct date";

    //validacion de numero entre 1 y 2 caracteres de longitud
    $validation_number = preg_match($caso2,$author_id);
    //Condicional verificacion de numero
    if($validation_number == 1){
        //Depuracion de validacion
        //echo "correct number";
        //Condicional de tipo de valor de dato para titulo
        if(is_string($title)){
            //Depuracion de validacion para titulo 
            //echo "correct title";
            $book = new book($date,$title,$author_id);
            $book->register();
        }
        else{
            echo "Incorrect title";
        }
    }
    else{
            echo "Incorrect id de Autor";
        }
}
else{
            echo "Incorrect Fecha";
        }
        //Depuracion de fecha
//echo $validation_date." - ".$validation_date2;