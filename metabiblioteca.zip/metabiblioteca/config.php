<?php
//Clase configuracion de coneccion a Base de datos
class Connection{
    //variables
	public $servername;
	public $database;
	public $username;
    public $password;
    public $con;
    public $table;
    public $hash;
    //constructor por tablas en base de datos
	public function __construct($table){
        //Asignacion local de configuracion de la conexion
        //Servidor
        $this->servername= "localhost";
        //Nombre Base de Datos
        $this->database= "prueba_meta";
        //usuario base de Datos
        $this->username= "root";
        //Clave Base de Datos
        $this->password= "";
        //Asignacion de tabla por instancia del objeto
        $this->table = $table;
        //creacion de objeto de coneccion
        $this->con = $this->get_connection();
    }

    //Get para la coneccion
    public function get_connection(){
        $connection = array($this->servername,$this->username,$this->password,$this->database);
        $my_sqlConnection = mysqli_connect($this->servername,$this->username,$this->password,$this->database);
        if (!$my_sqlConnection){
            die("Connection failed!!\n' :( \n".mysqli_connect_error());
        }
        else{
            $connect = $this->servername.",".$this->username.",".$this->password.",".$this->database;
            return $my_sqlConnection;
        }
    }

    //Funcion de insercion a tabla segun instancia -- Cada insdtancia de objeto se crea con propiedad con el nombe de la tabla 
    //en donde se ubicara este
    public function send_register($table,$columns,$data){
        $insert = "INSERT INTO ".$table." (".$columns.") VALUES (".$data.");";
        $mysql_query = mysqli_query($this->con,$insert);
        //Depuracion de consulta
        //echo $insert;
        //Control de errores de insercion
        if($mysql_query == 1){
            echo "\nInsercion Exitosa :)";
        }
        else{
            echo "\nError en Insercion :(";
            echo "\n".$insert;
            echo "\n".$mysql_error;
        }
        //devolucion de consulta
        echo $mysql_query;
        //Depuracion de salida
        //var_dump($this->con);
    }

    //Funcion validacion de existencia de datos en tabla
    public function validate_data($argA,$argB,$argC){
        $select = "SELECT count(".$argA.") FROM ".$argB." where ".$argA."='".$argC."';";
        $mysql_query = mysqli_query($this->con,$select);
        $mysql_fetch = mysqli_fetch_array($mysql_query);
        $mysql_fetch  = (int)$mysql_fetch [0];
        return $mysql_fetch;
    }
    //cuenta de datos en tabla
    public function count_data($argA,$argB){
        $select = "SELECT count(".$argA.") FROM ".$argB."';";
        $mysql_query = mysqli_query($this->con,$select);
        $mysql_fetch  = (int)$mysql_query[0];
        return $mysql_fetch;
    }
    //regresa la primera coincidencia con parametro where 
    public function con_select($argA,$argB,$argC){
		$query = "SELECT ".$argA." FROM `".$argB."` where ".$argC.";";
		$con_query = mysqli_query($this->con,$query);
		$con_query_fetch = mysqli_fetch_array($con_query);
		$con_query_fetch_n = $con_query_fetch[0];
		return $con_query_fetch_n;
    }
    //Devuelve arreglo con consulta realizada con parametro where
    public function con_select_array($argA,$argB,$argC){
		$query = "SELECT ".$argA." FROM `".$argB."` where ".$argC.";";
		$con_query = mysqli_query($this->con,$query);
		$con_query_fetch = mysqli_fetch_array($con_query);
		return $con_query_fetch;
	}
    //Devuelve primera coincidencia con consulta realizada sin parametro where
	public function con_select_single($argA,$argB){
		$query = "SELECT ".$argA." FROM `".$argB."` ;";
		$con_query = mysqli_query($this->con,$query);
		$con_query_fetch = mysqli_fetch_array($con_query);
		$con_query_fetch_n = $con_query_fetch[0];
		return $con_query_fetch_n;
    }
    //Devuelve arreglo con consulta realizada sin parametro where
    public function con_select_single_array($argA,$argB){
		$query = "SELECT ".$argA." FROM `".$argB."` ;";
		$con_query = mysqli_query($this->con,$query);
		return $con_query;
	}
   
}
?>