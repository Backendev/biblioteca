<?php
class Base{
    public $action;
    //Render de vistas completas con header y footer prediseñado
    function renderHtml($path){
        include 'config.php';
        include "views/base.php";
        include "views/".$path.'.php';
        include "views/footer.php";
        
    }
    //Render simple - solo resultado
    function rendersingleHtml($path){
        include "views/".$path.'.php';
        
    }
}