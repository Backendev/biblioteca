<?php
include 'base.php';


//Controlador para Autores
class author extends Base{
    //Constructor con nombre
    public function __construct(){
        $this->actions =array('author'=>$this->getAuthor('author'));
    }
    //Renderizacion de vista author
    public function getAuthor($path){
       echo $this->renderHTML($path);
    }
}