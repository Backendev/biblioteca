<?php
//importar controlador base
include 'base.php';
//Clase para traer la consulta de todos los libros
class getbooks extends Base{
    //llamada a funcion de render
    public function __construct(){
        $this->actions =array('getbooks'=>$this->getbooks('getbooks'));
    }
    //Render de vista getbooks
    public function getbooks($path){
       echo $this->renderHTML($path);
    }
}