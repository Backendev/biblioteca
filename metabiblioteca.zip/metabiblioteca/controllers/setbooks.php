<?php
//importar controlador base
include 'base.php';

class setbooks extends Base{
    //llamada a funcion de render
    public function __construct(){
        $this->actions =array('setbooks'=>$this->setbooks('setbooks'));
    }
    //render de vista setbooks
    public function setbooks($path){
       echo $this->rendersingleHTML($path);
    }
}