<?php
//Importar Modelo Base
include 'base.php';
//creacion de controlador para Libros
class book extends Base{
    //Accion a llamar para render
    public function __construct(){
        $this->actions =array('book'=>$this->getBooks('book'));
    }
    //render de vista book
    public function getBooks($path){
       echo $this->renderHTML($path);
    }
}