<?php
//importar controlador base
include 'base.php';


class setauthors extends Base{
    //llamada a funcion de render    
    public function __construct(){
        $name = $_POST['name'];
        $this->actions =array('setauthors'=>$this->setauthors('setauthors'));
    }
    //Render de vista setauthors
    public function setauthors($path){
       echo $this->rendersingleHTML($path);
    }
}