<?php
//FRONT CONTROLLER

class FrontController{
    private $request;
    private $paths = array('/metabiblioteca/authors'=>'author','/metabiblioteca/books'=>'book','/metabiblioteca/getbooks'=>'getbooks','/metabiblioteca/setbooks'=>'setbooks','/metabiblioteca/setauthors'=>'setauthors');
    public function __construct(){
        $page = $this->set_peticion($_SERVER['REQUEST_URI']);
        if($page != NULL){
            //var_dump($pagina);
            include "controllers/".$page.".php";
            $pagecontroller = new $page;
            $pagecontroller->action[$page];
        }
        
    }
    public function set_peticion($request){
        $this->request = $request;
        if($this->validate_path($request) != FALSE){
            return $this->paths[$request];
        }else{
            echo "NO EXISTE LA RUTA (404)";
        }
    }
    public function validate_path($request){
        foreach($this->paths as $item=> $values){
            if($item == $request){
                return $request;
            }
        }
        return FALSE;

    }
}