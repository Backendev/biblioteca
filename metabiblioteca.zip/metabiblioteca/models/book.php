<?php
//importar modelo base
include 'baseObject.php';

class book extends ObjectBase{
    //variables
    public $title;
    public $author_id;
    public $publish_date;

    //constructor con publish date , titulo, e Id de autor
    public function __construct($publish_date,$title,$author_id){
        $this->book_obj = new Connection('books');
        $this->columnsSignUp = 'publish_date,title,author_id';
        $this->table = 'book';
        $this->setTitle($title);
        $this->setPublishDate($publish_date);
        $this->setAuthorId($author_id);

    }

    //Getters & Setters
    public function getTitle(){
        return $this->title;
    }

    public function setTitle($title){
        $this->name = $title;
    }

    public function getAuthorId(){
        return $this->author_id;
    }

    public function setAuthorId($author_id){
        $this->author_id = $author_id;
    }

    public function getPublishDate(){
        return $this->publish_date;
    }

    public function setPublishDate($publish_date){
        $this->publish_date = $publish_date;
    }

    //Funcion envio de libros a base de datos
    public function register(){
        $data = '"'.$this->publish_date.'","'.$this->name.'","'.$this->author_id.'"';
        $this->book_obj->send_register($this->table,$this->columnsSignUp,$data);
    }

}