<?php

//Importar objeto de configuracion --Configuracion de base de datos
include_once 'config.php';

Class ObjectBase{
    public $table;
}