<?php
//importar objeto base
include 'baseObject.php';

class Author extends ObjectBase{
    //variables
    public $name;
    public $id;
    //constructor con nombre
    public function __construct($name){
        $this->author_obj = new Connection('author');
        $this->columnsSignUp = 'name';
        $this->table = 'author';
        $this->setName($name);

    }
    //Getters & Setters
    public function getName(){
        return $this->name;
    }

    public function setName($name){
        $this->name = $name;
    }

    //Funcion para enviar author a base de datos
    public function sendAuthor(){
        
        $data = '"'.$this->name.'"';
        $this->author_obj->send_register($this->table,$this->columnsSignUp,$data);
    }

}





