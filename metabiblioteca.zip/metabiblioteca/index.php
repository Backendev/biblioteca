<?php
error_reporting(E_ALL ^ E_NOTICE);
//Llamado a enrutador
include 'router.php';
//Instancia de Front Controller
$Router = new FrontController();